package cat.copernic.marcortiz.penjatfirebase2.models

data class User(val name:String ?= null, val date:String ?= null, val punts:String ?= null)
